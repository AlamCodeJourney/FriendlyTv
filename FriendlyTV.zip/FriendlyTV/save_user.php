<?php
// save_user.php
include 'config.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header('Location: register.php');
    exit;
}

// basic sanitize
$first = trim($_POST['first_name']);
$last  = trim($_POST['last_name']);
$mobile= trim($_POST['mobile']);
$email = trim($_POST['email']);
$pass  = $_POST['password'];
$dob   = $_POST['dob']; // YYYY-MM-DD
$country = trim($_POST['country']);

if (!$first || !$last || !$email || !$pass || !$dob || !$country) {
    header('Location: register.php?error=' . urlencode('Please fill all fields'));
    exit;
}

// age calc
$birth = new DateTime($dob);
$today = new DateTime();
$age = $today->diff($birth)->y;

if ($age < 0) {
    header('Location: register.php?error=' . urlencode('Invalid DOB'));
    exit;
}

// check duplicate email or mobile
$stmt = $conn->prepare("SELECT id FROM users WHERE email = ? OR mobile = ? LIMIT 1");
$stmt->bind_param('ss', $email, $mobile);
$stmt->execute();
$stmt->store_result();
if ($stmt->num_rows > 0) {
    $stmt->close();
    header('Location: register.php?error=' . urlencode('Email or mobile already registered'));
    exit;
}
$stmt->close();

// store user (hash password)
$hash = password_hash($pass, PASSWORD_DEFAULT);
$ins = $conn->prepare("INSERT INTO users (first_name,last_name,mobile,email,password,dob,country) VALUES (?,?,?,?,?,?,?)");
$ins->bind_param('sssssss', $first, $last, $mobile, $email, $hash, $dob, $country);
$ok = $ins->execute();
$ins->close();

if (!$ok) {
    header('Location: register.php?error=' . urlencode('Database error'));
    exit;
}

// Age decision: if >=18 -> go to login, else -> sorry with days left
if ($age >= 18) {
    header('Location: login.php?registered=1');
    exit;
} else {
    $adultDate = (new DateTime($dob))->modify('+18 years');
    $days_left = $today->diff($adultDate)->days;
    header('Location: sorry.php?days=' . $days_left);
    exit;
}
