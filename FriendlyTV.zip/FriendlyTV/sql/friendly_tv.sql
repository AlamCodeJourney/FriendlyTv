CREATE DATABASE IF NOT EXISTS `friendly_tv` DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci;
USE `friendly_tv`;

CREATE TABLE IF NOT EXISTS `users` (
  id INT AUTO_INCREMENT PRIMARY KEY,
  first_name VARCHAR(100),
  last_name VARCHAR(100),
  mobile VARCHAR(30),
  email VARCHAR(150) UNIQUE,
  password VARCHAR(255),
  dob DATE,
  country VARCHAR(100),
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
