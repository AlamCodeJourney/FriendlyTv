<?php include 'config.php'; ?>
<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width,initial-scale=1">
  <title>Friendly TV - Register</title>
  <link rel="stylesheet" href="assets/style.css">
</head>
<body class="dark">
  <main class="centered">
    <div class="card card-large">
      <div class="card-left">
        <h1 class="logo">Friendly <span class="pill">TV</span></h1>
        <h2>Create Account</h2>

        <?php if(isset($_GET['error'])): ?>
          <div class="alert error"><?php echo htmlentities($_GET['error']); ?></div>
        <?php endif; ?>

        <form id="regForm" action="save_user.php" method="POST" novalidate>
          <div class="row">
            <input type="text" name="first_name" placeholder="First name" required>
            <input type="text" name="last_name" placeholder="Last name" required>
          </div>

          <input type="text" name="mobile" placeholder="Mobile number" required>
          <input type="email" name="email" placeholder="Email" required>
          <input type="password" name="password" id="password" placeholder="Password" required>
          <input type="date" name="dob" placeholder="Date of Birth" required>
          <input type="text" name="country" placeholder="Country" required>

          <button class="btn primary" type="submit">Create Account</button>
        </form>

        <p class="muted">Already have an account? <a href="login.php">Login</a></p>
      </div>

      <div class="card-right" aria-hidden="true">
        <!-- Design image: local path provided -->
        <img src="assets/friendly_tv_art.png" alt="Friendly TV" />
      </div>
    </div>
  </main>

<script src="assets/script.js"></script>
</body>
</html>
