<?php
$days = isset($_GET['days']) ? (int)$_GET['days'] : 0;
?>
<!doctype html>
<html>
<head>
  <meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
  <title>Friendly TV - Sorry</title>
  <link rel="stylesheet" href="assets/style.css">
</head>
<body class="dark">
  <main class="centered">
    <div class="card card-sorry">
      <div class="pad">
        <div class="lock">18</div>
        <h2>Oops! You're not 18 yet.</h2>
        <p class="muted">Aapko 18 saal hone me abhi <strong><?php echo $days; ?></strong> din baki hain.</p>
        <a href="register.php" class="btn">Back to Home</a>
      </div>
    </div>
  </main>
</body>
</html>
