<?php
include 'config.php';
session_start();

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header('Location: login.php');
    exit;
}

$login = trim($_POST['login']);
$password = $_POST['password'];

$stmt = $conn->prepare("SELECT id, password, dob FROM users WHERE email = ? OR mobile = ? LIMIT 1");
$stmt->bind_param('ss', $login, $login);
$stmt->execute();
$res = $stmt->get_result();
$user = $res->fetch_assoc();
$stmt->close();

if (!$user) {
    header('Location: login.php?error=' . urlencode('Invalid credentials'));
    exit;
}

// verify password
if (!password_verify($password, $user['password'])) {
    header('Location: login.php?error=' . urlencode('Invalid credentials'));
    exit;
}

// check age again (safety)
$dob = new DateTime($user['dob']);
$today = new DateTime();
$age = $today->diff($dob)->y;

if ($age < 18) {
    $adultDate = (new DateTime($user['dob']))->modify('+18 years');
    $days_left = $today->diff($adultDate)->days;
    header('Location: sorry.php?days=' . $days_left);
    exit;
}

// success: set session
$_SESSION['user_id'] = $user['id'];
header('Location: content.php');
exit;
