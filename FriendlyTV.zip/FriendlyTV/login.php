<?php include 'config.php'; ?>
<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Friendly TV - Login</title>

<style>
    body {
        margin: 0;
        height: 100vh;
        background: linear-gradient(to bottom, #0f0c29, #302b63, #24243e);
        font-family: Arial, sans-serif;
        display: flex;
        justify-content: center;
        align-items: center;
    }

    .centered {
        width: 100%;
        display: flex;
        justify-content: center;
        padding: 20px;
    }

    .card-medium {
        width: 100%;
        max-width: 450px;
        background: rgba(0, 0, 0, 0.55);
        backdrop-filter: blur(10px);
        padding: 35px;
        border-radius: 18px;
        box-shadow: 0 0 25px rgba(0, 0, 0, 0.5);
        text-align: center;
        color: white;
    }

    .logo {
        font-size: 36px;
        font-weight: 700;
        margin: 0;
    }

    .pill {
        background: red;
        color: white;
        padding: 4px 7px;
        border-radius: 6px;
        font-size: 20px;
        margin-left: 5px;
    }

    h2 {
        margin: 10px 0 25px;
        font-weight: 300;
        color: #ddd;
    }

    input {
        width: 100%;
        padding: 13px;
        margin-bottom: 15px;
        border-radius: 8px;
        border: none;
        font-size: 15px;
        outline: none;
    }

    .btn.primary {
        width: 100%;
        padding: 13px;
        background: #ff5f45;
        color: white;
        border: none;
        border-radius: 8px;
        font-size: 17px;
        cursor: pointer;
        margin-top: 10px;
    }

    .btn.primary:hover {
        background: #ff371c;
    }

    .muted {
        color: #ccc;
        margin-top: 15px;
        font-size: 15px;
    }
    .muted a {
        color: #7ab6ff;
    }

    .alert {
        padding: 12px;
        border-radius: 6px;
        margin-bottom: 15px;
        font-size: 15px;
    }
    .alert.success {
        background: rgba(0, 255, 0, 0.15);
        color: #b8ffb8;
        border-left: 4px solid #0f0;
    }
    .alert.error {
        background: rgba(255, 0, 0, 0.18);
        color: #ffbcbc;
        border-left: 4px solid red;
    }

    /* 🖥 Desktop Fix – perfect centering + polished look */
    @media (min-width: 1024px) {
        .card-medium {
            max-width: 460px;
            transform: translateY(-20px);
        }
        .logo {
            font-size: 40px;
        }
    }
</style>

</head>

<body>

<main class="centered">
  <div class="card card-medium">

    <h1 class="logo">Friendly <span class="pill">TV</span></h1>
    <h2>Login to Continue</h2>

    <?php if(isset($_GET['registered'])): ?>
      <div class="alert success">Account created. Please login.</div>
    <?php endif; ?>

    <?php if(isset($_GET['error'])): ?>
      <div class="alert error"><?php echo htmlentities($_GET['error']); ?></div>
    <?php endif; ?>

    <form action="verify_login.php" method="POST">
      <input type="text" name="login" placeholder="Email or Mobile" required>
      <input type="password" name="password" placeholder="Password" required>
      <button class="btn primary" type="submit">Login to Continue</button>
    </form>

    <p class="muted">Don't have an account? <a href="register.php">Create one</a></p>
  </div>
</main>

</body>
</html>
