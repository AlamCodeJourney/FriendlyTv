// assets/script.js
document.addEventListener('DOMContentLoaded', function(){
  var reg = document.getElementById('regForm');
  if(!reg) return;
  reg.addEventListener('submit', function(e){
    var p = document.getElementById('password').value;
    if(p.length < 6){
      e.preventDefault();
      alert('Password must be at least 6 characters');
      return false;
    }
  });
});
