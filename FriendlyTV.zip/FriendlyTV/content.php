<?php
session_start();
include 'config.php';
if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit;
}
$stmt = $conn->prepare("SELECT first_name FROM users WHERE id = ?");
$stmt->bind_param('i', $_SESSION['user_id']);
$stmt->execute();
$res = $stmt->get_result();
$user = $res->fetch_assoc();
$stmt->close();
?>
<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>Friendly TV</title>

<style>
body{margin:0;background:#0f0f0f;color:#fff;font-family:Arial}
header{
    display:flex;justify-content:space-between;align-items:center;
    padding:15px 25px;background:#1a1a1a;border-bottom:1px solid #333;
    position:sticky;top:0;z-index:10;
}
.logo{font-size:24px;font-weight:bold;}
.pill{background:#ff0000;padding:3px 8px;border-radius:5px;}
.search-box{flex:1;display:flex;gap:10px;margin:0 40px;}
.search-box input{
    flex:1;padding:10px;border:none;border-radius:20px;
    background:#222;color:#fff;font-size:16px;
}
.search-box button{
    padding:10px 18px;border:none;border-radius:20px;
    background:#ff0000;color:#fff;font-weight:bold;cursor:pointer;
}
.videos{
    display:grid;
    grid-template-columns:repeat(auto-fill,minmax(280px,1fr));
    gap:20px;padding:20px;
}
.video{
    background:#181818;border-radius:10px;overflow:hidden;
    cursor:pointer;transition:.2s;
}
.video:hover{transform:scale(1.03);}
.video img{width:100%;height:170px;object-fit:cover;}
.title{padding:10px;font-size:15px;}

#playerBox{
    width:100%;max-width:900px;margin:20px auto;display:none;
}
#player{width:100%;height:450px;border:none;border-radius:10px;}
</style>

</head>
<body>

<header>
    <h2 class="logo">Friendly <span class="pill">TV</span></h2>

    <div class="search-box">
        <input type="text" id="searchInput" placeholder="Search on YouTube...">
        <button onclick="searchYT()">Search</button>
    </div>

    <div>
        Hi, <?php echo htmlentities($user['first_name']); ?>
        <a href="logout.php" style="color:#ff0000;margin-left:10px;">Logout</a>
    </div>
</header>

<div id="playerBox">
    <iframe id="player"></iframe>
</div>

<h2 style="padding-left:20px;">Recommended</h2>

<div class="videos" id="videoList"></div>

<script>
// DEFAULT VIDEOS (Comedy + Songs + Islamic Dua)
let defaultVideos = [
    "dQw4w9WgXcQ","V-_O7nl0Ii0","3JZ_D3ELwOQ","hY7m5jjJ9mM","ktvTqknDobU",
    "0KSOMA3QBU0","l482T0yNkeo","sAzlWScHTc4","Z1BCujX3pw8","q6EoRBvdVPQ",
    "iLbbpRYwKZg","TUVcZfQe-Kw","Nf7T6fQe-Kw","e-ORhEE9VVg","mWRsgZuwf_8",
    "MoqY0ZrW4pw","e1P0cmIrVdY","HgzGwKwLmgM","2Vv-BfVoq4g","pRpeEdMmmQ0",
    "hT_nvWreIhg","pXRviuL6vMY","RgKAFK5djSk","UceaB4D0jpo","JGwWNGJdvx8",
    "gOsM-DYAEhY","U9BwWKXjVaI","K5KAc5CoCuk","uelHwf8o7_U"
];

// Load default videos on page
window.onload = function(){
    loadVideos(defaultVideos);
};

function loadVideos(list){
    let box = document.getElementById("videoList");
    box.innerHTML = "";
    list.forEach(id=>{
        box.innerHTML += `
        <div class="video" onclick="playVideo('${id}')">
            <img src="https://img.youtube.com/vi/${id}/mqdefault.jpg">
            <div class="title">Video ID: ${id}</div>
        </div>`;
    });
}

function playVideo(id){
    document.getElementById("playerBox").style.display = "block";
    document.getElementById("player").src = 
        "https://www.youtube.com/embed/" + id + "?autoplay=1";
}

function searchYT(){
    let q = document.getElementById("searchInput").value.trim();
    if(q.length < 1) return;

    let API_KEY = "YOUR_YOUTUBE_API_KEY_HERE"; // <-- ADD HERE

    fetch(`https://www.googleapis.com/youtube/v3/search?part=snippet&type=video&maxResults=25&q=${encodeURIComponent(q)}&key=${API_KEY}`)
    .then(r=>r.json())
    .then(data=>{
        if(!data.items){ alert("Search failed."); return; }
        let ids = data.items.map(v=>v.id.videoId);
        loadVideos(ids);
    })
    .catch(()=>alert("Search failed. Try again."));
}
</script>

</body>
</html>
